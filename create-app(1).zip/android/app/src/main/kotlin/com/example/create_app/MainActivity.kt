package com.example.create_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
